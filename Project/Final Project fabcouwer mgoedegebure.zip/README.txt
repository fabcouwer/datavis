This is our handin for the Data Visualization course.
In this archive you will find the following:

- Code (Java), containing our Java code.
- Report, containing our report and summaries of our individual contributions to the project
- Website, containing the code and datasets for the resulting webpage

To view the visualization, please open the "index.html" file in the Website folder in Firefox or Chrome.

Friso Abcouwer - 4019873 - F.C.A.Abcouwer@student.tudelft.nl
Marijn Goedegebure - 4013484 - marijngoedegebure@gmail.com