This handin consists of the following files:

- A report, "Report DotA2 Assignment fabcouwer mgoedegebure.pdf".
- Java source code, in the DataExtraction/ folder.
- A webpage showing our visualizations, DotaVisualization.html.
- CSV and JavaScript Files needed for the webpage to work.

We recommend reading the report first before looking at the visualizations.