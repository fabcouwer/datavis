This folder contains our report for the VolVis assignment for the Data Visualization course.
It consists of the following files:

- Volvis Report.html -> A 'blog post'-styled report
- Images -> Folder with images all used in the report
- Bootstrap/jquery files -> Used for the report layout

Authors:
Friso Abcouwer - 4019873 - F.C.A.Abcouwer@student.tudelft.nl
Marijn Goedegebure - 4013484 - Marijngoedegebure@gmail.com